package jconnect.database;
import java.util.ArrayList;


public class ResultFromDB {
//	ArrayList<ArrayList<String>> result = new ArrayList<ArrayList<String>>();
	

//	public ResultFromDB(int row, int column) {
//		this.row = row;
//		this.column = column;
//	}
	
//	public void addContent() {
//		
//	}
	
//	public void printInfo() {
//		for (int i =0; i < row; i++) {
//			for( int j = 0; j < column; j++)
//				System.out.println(Result[i][j]);
//		}
//	}
}
